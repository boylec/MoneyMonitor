package Core.Models;

public class CredentialSet {
	public String userName = "";
	public String password = "";
}
